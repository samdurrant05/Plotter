from DRV8825 import DRV8825
import controllers.controllers as controller
import concurrent.futures
import time
import RPi.GPIO as GPIO
import os
from display import Display



class Executor:
    def __init__(self, file):
        self.file = file
        print(self.file)
        self.display = Display()

        # Component Initialisation
        # Solenoid
        solenoid_pin = 5 # To be configured

        # Motors
        step_type = 'Full'

        # Left Motor
        dir_pin_left=13
        step_pin_left=19
        enable_pin_left=12
        mode_pins_left=(16, 17, 20)

        # Motor 2
        dir_pin_right=24
        step_pin_right=18
        enable_pin_right=4
        mode_pins_right=(21, 22, 27)
        self.solenoid = controller.Solenoid(solenoid_pin)
        self.pen_up(1)
        #self.left_motor = controller.StepperMotor(enable_pin_left, step_pin_left, dir_pin_left, mode_pins_left, step_type)
        #self.right_motor = controller.StepperMotor(enable_pin_right, step_pin_right, dir_pin_right, mode_pins_right, step_type)
        self.right_motor = DRV8825(dir_pin=13, step_pin=19, enable_pin=12, mode_pins=(16, 17, 20))
        self.left_motor = DRV8825(dir_pin=24, step_pin=18, enable_pin=4, mode_pins=(21, 22, 27))

        self.right_motor.SetMicroStep("hardward", "fullstep")
        self.left_motor.SetMicroStep("hardward", "fullstep")
        #self.start_test()
        self.microsteps = 32
        self.step_delay = 0.000390625
        #self.correction_factor = 1.075
        self.correction_factor = 1

        with open(self.file, 'r') as f:
            self.execute(f.read())

    def start_test(self):
        os.system("python3 /home/pi/2DPlotter/PiComponentCode/test.py")




    def execute(self, rle_instructions):
        self.display.set_text("Plodding...", 1)
        start_time = time.time()

        start_pointer = 0
        end_pointer = 0

        while start_pointer < len(rle_instructions):
            if rle_instructions[end_pointer].isdigit():
                end_pointer += 1
            else:
                self.interface(rle_instructions[end_pointer], int(rle_instructions[start_pointer:end_pointer] or 1))
                end_pointer += 1
                start_pointer = end_pointer
                #time.sleep(0.00001)
        #self.left_motor.run(1, True)
        #self.right_motor.run(1, True)
        self.display.clear_row("ALL")
        self.display.set_text("Plotting Complete.", 1)
        self.pen_up(1)
        end_time = time.time()
        total_time = end_time - start_time
        minutes = int(total_time // 60)
        seconds = round(total_time % 60)
        self.display.set_text(f"Time Taken: {minutes}m {seconds}s", 2)
        self.solenoid.disengage()
        GPIO.cleanup()
        time.sleep(10)

    def interface(self, instruction, iterations):
        match instruction:
            case "U":
                self.pen_up(iterations)
            case "D":
                self.pen_down(iterations)
            case "L":
                self.rotate_left(iterations)
            case "R":
                self.rotate_right(iterations)
            case "F":
                self.move_forward(iterations)

    def pen_up(self, iters):
        for i in range(iters):
            self.solenoid.disengage()
            print("Pen Up")

        # pick pen up solenoid control here
        pass

    def pen_down(self, iters):
        for i in range(iters):
            self.solenoid.engage()
            print("Pen Down")
        # put down pen solenoid control here
        pass

    def move_forward(self, iters):
        print("move forward") #was 32
        with concurrent.futures.ThreadPoolExecutor() as threadexecutor:
            t1 = threadexecutor.submit(self.left_motor.TurnStep, "forward", int(round(iters*self.microsteps*self.correction_factor)), self.step_delay)
            t2 = threadexecutor.submit(self.right_motor.TurnStep, "forward", int(round(iters*self.microsteps*self.correction_factor)), self.step_delay)
            #t1 = threadexecutor.submit(self.left_motor.run, iters*32, True)
            #t2 = threadexecutor.submit(self.right_motor.run, iters*32, True)
           time.sleep(0.5)
        #test pass, remove below if necessary (added later)
        #pass
        # put go forward motor control here

    def rotate_right(self, iters):
        print("rotate right") #was 32.1
        with concurrent.futures.ThreadPoolExecutor() as threadexecutor:
            t3 = threadexecutor.submit(self.left_motor.TurnStep, "forward", int(round(iters*self.microsteps*self.correction_factor)), self.step_delay)
            t4 = threadexecutor.submit(self.right_motor.TurnStep, "backward", int(round(iters*self.microsteps*self.correction_factor)), self.step_delay)
            #t3 = threadexecutor.submit(self.left_motor.run, iters*32, True)
            #t4 = threadexecutor.submit(self.right_motor.run, iters*32, False)
            pass
        # put turn right motor control here
        pass

    def rotate_left(self, iters):
        print("rotate left")
        with concurrent.futures.ThreadPoolExecutor() as threadexecutor:
            t5 = threadexecutor.submit(self.left_motor.TurnStep, "backward", int(round(iters*self.microsteps*self.correction_factor)), self.step_delay)
            t6 = threadexecutor.submit(self.right_motor.TurnStep, "forward", int(round(iters*self.microsteps*self.correction_factor)), self.step_delay)
            #t5 = threadexecutor.submit(self.left_motor.run, iters*32, False)
            #t6 = threadexecutor.submit(self.right_motor.run, iters*32, True)
            pass
        pass


myExecutor = Executor("/home/pi/2DPlotter/PiComponentCode/Input/plodderinstructions/nflcxf.txt")

