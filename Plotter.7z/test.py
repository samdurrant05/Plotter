#import controllers.controllers as controller
from DRV8825 import DRV8825
import time
import concurrent.futures
from display import Display
#3600

class Tester:
    def __init__(self):
        self.display = Display()
        self.display.set_text("Testing", 1)
        pass
    
    def test(self):
        enable_pin = 12
        step_pin = 19
        dir_pin = 13
        mode_pins=(16, 17, 20)
        step_type = 'Full'
        motor = DRV8825(dir_pin=13, step_pin=19, enable_pin=12, mode_pins=(16, 17, 20))
        motor2 = DRV8825(dir_pin=24, step_pin=18, enable_pin=4, mode_pins=(21, 22, 27))
        #motor.SetMicroStep('softward','fullstep')
        with concurrent.futures.ThreadPoolExecutor() as threadexecutor:
            t1 = threadexecutor.submit(motor.TurnStep, "backward", 400, 0.001)
            t2 = threadexecutor.submit(motor2.TurnStep, "backward", 400, 0.001)
            
        with concurrent.futures.ThreadPoolExecutor() as threadexecutor:
            t1 = threadexecutor.submit(motor.TurnStep, "forward", 400, 0.001)
            t2 = threadexecutor.submit(motor2.TurnStep, "forward", 400, 0.001)
        #motor.TurnStep("backward", 12800, stepdelay=0.0001)
        
        #motor.TurnStep("forward", 12800, stepdelay=0.0001)
        


test = Tester()
test.test()
