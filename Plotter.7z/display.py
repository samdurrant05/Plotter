#!usr/bin/env python3

import lcdrw1063 as LCD
display = LCD.Lcd()

from time import sleep

class Display:
    def __init__(self):
        self.display = LCD.Lcd()
        self.display_length = 20

    def scroll_text_once(self, text, row):
        display.lcd_display_string(text[:32], row)
        text = text[1:] + text[0]
        sleep(0.5)
        return text
    
    def set_text(self, text, row):
        self.clear_row(row)
        display.lcd_display_string(text, row)
    
    def clear_row(self, row):
        if row != "ALL":
            display.lcd_display_string(" "*20, row)
        else:
            display.lcd_display_string(" "*20, 1)
            display.lcd_display_string(" "*20, 2)
            
    def test_scrolling_text(self, text, row):
        while len(text) < 20:
            text += " "
        text = text[:29]
        text += "   "
        while True:
            display.lcd_display_string(text, row)
            text = text[1:] + text[0]
            sleep(0.5)

