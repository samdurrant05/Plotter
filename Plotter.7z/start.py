from controller import Controller

controller = Controller()
